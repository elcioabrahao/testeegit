/**
 * 
 */
package exercicio5;

/**
 * @author sbonato
 *
 */
public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Progressao progressao = new Progressao();
		progressao.aritmetica(5, 3);
		progressao.geometrica(5, 2);

	}

}
