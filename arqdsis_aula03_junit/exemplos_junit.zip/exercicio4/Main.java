package exercicio4;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		MegaSena mega = new MegaSena();
		mega.geraDezenas(mega.quantidadeDezenas());

	}

}
