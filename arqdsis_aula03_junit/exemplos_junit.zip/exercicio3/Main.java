package exercicio3;


/**
 * @author sbonato
 * Inicia o programa.
 */
public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Cadastro cadastro = new Cadastro();
		cadastro.cadastro();

	}

}
