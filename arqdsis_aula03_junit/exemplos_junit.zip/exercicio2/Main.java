/**
 * 
 */
package exercicio2;

/**
 * @author sbonato
 * Inicia o cadastro de notas
 */
public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Notas notas = new Notas();
		notas.leEImprimeNotas();

	}

}
